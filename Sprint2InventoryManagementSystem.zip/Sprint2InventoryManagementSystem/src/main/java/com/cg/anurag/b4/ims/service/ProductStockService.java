package com.cg.anurag.b4.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.b4.ims.dao.ProductStockDAO;
import com.cg.anurag.b4.ims.dto.ProductStock;

@Service
public class ProductStockService {
	@Autowired
    ProductStockDAO psdao;
	public void setpsdao(ProductStockDAO psdao) { this.psdao=psdao;}
	@Transactional(readOnly=true)
	public ProductStock getOrder(int orderId)
	{
		return psdao.findById(orderId).get();
	}
	 @Transactional
	    public String updateExitDate(ProductStock productStock)
	    {
	    	ProductStock productStock1 = psdao.findById(productStock.getOrderId()).get();
	    	if(productStock1!=null)
	    	{
	    	  productStock1.setExitDate(productStock.getExitDate());
	    	  return "Exit Date Modified";
	    	}
	    	return "Updation Failed";
	    }
	 @Transactional
	    public String updateStock(ProductStock productStock)
	    {
		 ProductStock productStock2 = psdao.findById(productStock.getOrderId()).get();
		 if(productStock2!=null)
		 {
			 productStock2.setManufacturingDate(productStock.getManufacturingDate());
			 productStock2.setExpiryDate(productStock.getExpiryDate());
			 productStock2.setQualityCheck(productStock.getQualityCheck());
			 return " Updated Stock Sucessfully";
		 }
		 return "Updation Failed";
	    }

	 

}
