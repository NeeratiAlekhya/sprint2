package com.cg.anurag.b4.ims.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.anurag.b4.ims.dto.ProductOrders;
import com.cg.anurag.b4.ims.service.ProductOrdersService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController 
public class ProductOrdersController 
{
	@Autowired
	ProductOrdersService productService;
	public void setProductService(ProductOrdersService productService)
	{
		this.productService=productService;
	}
	
   @GetMapping("/getProduct/{productId}")
   public ProductOrders getproduct(@PathVariable String orderId)
   {
	   return productService.getProduct(orderId);
   }
   
  
   @GetMapping("/getProducts")
   public List<ProductOrders> getProducts()
   {
	   return productService.getProducts();
   }

   @PostMapping(value="/addProduct",consumes="application/json")
   public ResponseEntity<String> insertProduct(@RequestBody()ProductOrders product)
   {
	   String message="Product Inserted Successfully";
	   if(productService.insertProduct(product)==null)
		   message="Product Insertion Failed";
	   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
   }
   
   @PutMapping(value="/updateProduct",consumes="application/json")
   public String updateProduct(@RequestBody()ProductOrders product)
   {
	   String message=productService.updateProduct(product);
	   return message;
   }
   
   @DeleteMapping("/deletProduct/{productId}")
   public String deleteProduct(@PathVariable String orderId)
   {
	   return productService.deleteProduct(orderId); 
   }
}
