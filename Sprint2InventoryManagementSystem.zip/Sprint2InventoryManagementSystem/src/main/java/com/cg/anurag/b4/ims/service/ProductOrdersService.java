package com.cg.anurag.b4.ims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.anurag.b4.ims.dao.ProductOrdersDAO;
import com.cg.anurag.b4.ims.dto.ProductOrders;

@Service
public class ProductOrdersService {
	 @Autowired
	    ProductOrdersDAO Pdao;
	    public void setBdao(ProductOrdersDAO pdao) { this.Pdao=pdao;}
	    @Transactional
	    public ProductOrders insertProduct(ProductOrders product)
	    {
	        return Pdao.save(product);
	    }
	    @Transactional(readOnly=true)
	    public ProductOrders getProduct(String orderId)
	    {
	    	return Pdao.findById(orderId).get();
	    }
	    @Transactional(readOnly=true)
	    public List<ProductOrders> getProducts()
	    {
	    	return Pdao.findAll();
	    }
	    @Transactional
	    public String deleteProduct(String orderId)
	    {
	    	Pdao.deleteById(orderId);
	    	return "Product Deleted";
	    }
	    
	    @Transactional
	    public String updateProduct(ProductOrders newProduct)
	    {
	    	ProductOrders product = Pdao.findById(newProduct.getOrderId()).get();
	    	if(product!=null)
	    	{
	    		product.setDeliveryStatus(newProduct.getDeliveryStatus());
	    	  return "Product Modified";
	    	}
	    	return "Update Failed";
	    }
	    
	}
