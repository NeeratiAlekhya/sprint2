package com.cg.anurag.b4.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.b4.ims.dao.RawMaterialStockDAO;
import com.cg.anurag.b4.ims.dto.RawMaterialStock;
@Service
public class RawMaterialStockService {
	@Autowired
	RawMaterialStockDAO rmsdao;
	public void setpsdao(RawMaterialStockDAO rmsdao) { this.rmsdao=rmsdao;}
	@Transactional(readOnly=true)
	public RawMaterialStock getOrder(int orderId) {
		// TODO Auto-generated method stub
		return rmsdao.findById(orderId).get();
	}
	 @Transactional
	    public String updateProcessDate(RawMaterialStock rawMaterialStock)
	    {
	    	RawMaterialStock rawMaterialStock1 = rmsdao.findById(rawMaterialStock.getOrderId()).get();
	    	if(rawMaterialStock1!=null)
	    	{
	    	  rawMaterialStock1.setProcessDate(rawMaterialStock.getProcessDate());
	    	  return "Process Date Modified";
	    	}
	    	return "Updation Failed";
	    }
	 @Transactional
	public String updateStock(RawMaterialStock rawMaterialStock) {
		 RawMaterialStock rawMaterialStock1 = rmsdao.findById(rawMaterialStock.getOrderId()).get();
	    	if(rawMaterialStock1!=null)
	    	{
	    	  rawMaterialStock1.setManufacturingDate(rawMaterialStock.getManufacturingDate());
	    	  rawMaterialStock1.setExpiryDate(rawMaterialStock.getExpiryDate());
	    	  rawMaterialStock1.setQualityCheck(rawMaterialStock.getQualityCheck());
	    	  return "Updated Stock Sucessfully";
	    	}
	    	return "Updation Failed";
	}

}
